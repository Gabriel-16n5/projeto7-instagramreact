const usuario = [
    {
        p1:467,
        p2:894,
        p3:653
    },
    {
        u1:"adorable_animals",
        u2:"respondeai",
        u3:"AmoAmar"
    },
]

export default usuario;