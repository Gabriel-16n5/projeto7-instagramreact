const infoSugestoes = [
    {
        url: "assets/img/bad.vibes.memes.svg",
        urlAlt: "bad.vibes.memes.svg",
        user: "bad.vibes.memes",
        stats: "Segue você"
    },
    {
        url: "assets/img/chibirdart.svg",
        urlAlt: "chibirdart",
        user: "chibirdart",
        stats: "Segue você"
    },
    {
        url: "assets/img/razoesparaacreditar.svg",
        urlAlt: "razoesparaacreditar",
        user: "razoesparaacreditar",
        stats: "Novo no Instagram"
    },
    {
        url: "assets/img/adorable_animals.svg",
        urlAlt: "adorable_animals",
        user: "adorable_animals",
        stats: "Segue você"
    },
    {
        url: "assets/img/smallcutecats.svg",
        urlAlt: "smallcutecats",
        user: "smallcutecats",
        stats: "Segue você"
    },
];

export default infoSugestoes;